Pyramid Clinic TWA address/share bar fix

Upload the .well-known folder to the ROOT of the GitHub Pages repository that serves:
https://km01208178584-source.github.io/

The final public URL must be exactly:
https://km01208178584-source.github.io/.well-known/assetlinks.json

Do NOT place it inside /Clinic/.well-known/ because the Android app's verified origin is the domain root.

After publishing, open the URL above in a browser. It must show the JSON array (not a 404, HTML page, or GitHub repository page).
Then force-stop the installed Android app and launch it again. If Android cached the unverified state, uninstall/reinstall the APK and launch again.

The JSON package name and SHA-256 signing certificate fingerprint were checked against the supplied signing.keystore. Keep signing.keystore and its passwords private; never upload them to GitHub.
